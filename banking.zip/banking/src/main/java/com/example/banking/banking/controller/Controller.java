package com.example.banking.banking.controller;

import com.example.banking.banking.dto.AccountDto;
import com.example.banking.banking.service.impl.ServiceImpl;
import org.apache.coyote.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping(value = "/account")
public class Controller {

    private final ServiceImpl service;

    public Controller(ServiceImpl service) {
        this.service = service;
    }

    @PostMapping("/create")
    public ResponseEntity<AccountDto> add(@RequestBody AccountDto accountDto){
        return new ResponseEntity<>(service.createAccount(accountDto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AccountDto> get(@PathVariable Long id){
        AccountDto accountDto =  service.getAccount(id);
        return new ResponseEntity<>(accountDto,HttpStatus.OK);
    }

    @PutMapping("/{id}/deposit")
    public ResponseEntity<AccountDto> deposit(@PathVariable Long id, @RequestBody Map<String,Double> request){
        AccountDto accountDto =  service.deposit(id,request.get("amount"));
        return new ResponseEntity<>(accountDto,HttpStatus.OK);
    }
}
