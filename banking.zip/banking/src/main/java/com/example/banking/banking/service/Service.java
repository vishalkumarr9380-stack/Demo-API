package com.example.banking.banking.service;

import com.example.banking.banking.dto.AccountDto;

public interface Service {

    AccountDto createAccount(AccountDto accountDto);
    AccountDto getAccount(Long id);
    AccountDto deposit(Long id,double balance);
}
