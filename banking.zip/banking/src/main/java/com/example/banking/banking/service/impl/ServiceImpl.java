package com.example.banking.banking.service.impl;

import com.example.banking.banking.dto.AccountDto;
import com.example.banking.banking.entity.AccountEntity;
import com.example.banking.banking.mapper.Mapper;
import com.example.banking.banking.repository.AccountRepository;
import com.example.banking.banking.service.Service;

@org.springframework.stereotype.Service
public class ServiceImpl implements Service {

    AccountRepository accountRepository;

    public ServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public AccountDto createAccount(AccountDto accountDto) {
        AccountEntity savedAccount = accountRepository.save(Mapper.mapToAccount(accountDto));
        return Mapper.mapToAccoutDto(savedAccount);
    }

    @Override
    public AccountDto getAccount(Long id) {
        AccountEntity getAccount = accountRepository.findById(id).
                orElseThrow(()-> new RuntimeException("Account not present with id: "+ id));
        return Mapper.mapToAccoutDto(getAccount);
    }

    @Override
    public AccountDto deposit(Long id, double balance) {
        AccountEntity account = accountRepository.findById(id).
                orElseThrow(()-> new RuntimeException("Account not present with id: "+ id));
        double total = account.getBalance() + balance;
        account.setBalance(total);
        AccountEntity saveAccount = accountRepository.save(account);
        return Mapper.mapToAccoutDto(saveAccount);
    }
}
