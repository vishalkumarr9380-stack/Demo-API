package com.example.banking.banking.mapper;

import com.example.banking.banking.dto.AccountDto;
import com.example.banking.banking.entity.AccountEntity;

public class Mapper {

    public static AccountEntity mapToAccount(AccountDto accountDto){
        return new AccountEntity(
                accountDto.getId(),
                accountDto.getAccountHolderName(),
                accountDto.getBalance()
        );
    }

    public static AccountDto mapToAccoutDto(AccountEntity account){
        return new AccountDto(
                account.getId(),
                account.getAccountHolderName(),
                        account.getBalance()
                );
    }
}
