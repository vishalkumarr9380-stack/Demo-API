package com.quizApp.quiz.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "question_entity")
public class QuestionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    private String questions;
    private String category;
}
