package com.quizApp.quiz.dao;

import com.quizApp.quiz.model.QuestionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuestionDao extends JpaRepository<QuestionEntity,Integer> {

    List<QuestionEntity> findByCategory(String category);

    @Query(value = "SELECT *  FROM quiz_entity Where q.category:category",nativeQuery = true)
    List<QuestionEntity> getRandomQuestions(@Param("category") String category);
}
