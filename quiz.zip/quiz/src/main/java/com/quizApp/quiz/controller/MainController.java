package com.quizApp.quiz.controller;

import com.quizApp.quiz.model.QuestionEntity;
import com.quizApp.quiz.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/question")
public class MainController {

    @Autowired
    QuestionService service;

    @GetMapping("/allQuestions")
    public List<QuestionEntity> getAllQuestions() {
        return service.getAllQuestions().getBody();
    }

    @GetMapping("category/{category}")
    private List<QuestionEntity> getQuestionByCategory(@PathVariable String category){
        return service.getAllQuestionsByCategory(category);
    }
    
    @PostMapping("/add")
    private ResponseEntity<String> addQuestion(@RequestBody QuestionEntity question){
        return service.addQuestion(question);
    }

    @DeleteMapping("/delete")
    private String deleteQuestions(@RequestBody QuestionEntity question){
        return service.delete(question);
    }
}

