package com.quizApp.quiz.service;

import com.quizApp.quiz.dao.QuestionDao;
import com.quizApp.quiz.model.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

    @Autowired
    QuestionDao questionDao;
    public ResponseEntity<List<QuestionEntity>> getAllQuestions() {
        return new ResponseEntity<>(questionDao.findAll(), HttpStatus.OK);
    }

    public List<QuestionEntity> getAllQuestionsByCategory(String category) {
        return questionDao.findByCategory(category);
    }

    public ResponseEntity<String> addQuestion(QuestionEntity question) {
        try {
            if(!question.getCategory().isEmpty()) {
                questionDao.save(question);
                return new ResponseEntity<>("Success", HttpStatus.CREATED);
            }
            else {
                return new ResponseEntity<>("Bad Request Passes",HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

    }

    public String delete(QuestionEntity question) {
        questionDao.deleteById(question.getId());
        return "Deleted";
    }
}
