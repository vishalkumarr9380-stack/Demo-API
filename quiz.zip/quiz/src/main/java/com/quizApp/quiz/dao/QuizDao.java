package com.quizApp.quiz.dao;

import com.quizApp.quiz.model.QuizEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuizDao extends JpaRepository<QuizEntity,Integer> {
}
