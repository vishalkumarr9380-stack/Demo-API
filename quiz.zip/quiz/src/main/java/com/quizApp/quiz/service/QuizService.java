package com.quizApp.quiz.service;

import com.quizApp.quiz.dao.QuestionDao;
import com.quizApp.quiz.dao.QuizDao;
import com.quizApp.quiz.model.QuestionEntity;
import com.quizApp.quiz.model.QuizEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizService {

    @Autowired
    QuizDao quizDao;
    @Autowired
    QuestionDao questionDao;

    public ResponseEntity<String> addQuiz(String category, String title) {

        QuizEntity quiz = new QuizEntity();
        List<QuestionEntity> question = questionDao.getRandomQuestions(category);

        quiz.setTitle(title);
        quiz.setQuestions(question);
        quizDao.save(quiz);
        return new ResponseEntity<>("Success", HttpStatus.CREATED);
    }
}
