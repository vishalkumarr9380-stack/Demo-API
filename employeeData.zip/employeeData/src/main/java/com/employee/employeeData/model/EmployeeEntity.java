package com.employee.employeeData.model;

import jakarta.persistence.*;
import lombok.Getter;

@Entity
@Table
@Getter
public class EmployeeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    private String unique;
    private String firstName;
    private String lastName;
    private String location;
}
