package com.employee.employeeData.service;

import com.employee.employeeData.dao.EmployeeDao;
import com.employee.employeeData.model.EmployeeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

    @Autowired
    EmployeeDao employeeDao;

    public ResponseEntity<String> add(EmployeeEntity employeeEntity) {
        try {
            if (!employeeEntity.getUnique().isEmpty() && !employeeEntity.getFirstName().isEmpty()) {
                employeeDao.save(employeeEntity);
                return new ResponseEntity<>("Inserted", HttpStatus.CREATED);
            }else {
                return new ResponseEntity<>("Bad Payload",HttpStatus.BAD_REQUEST);
            }
        }  catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
